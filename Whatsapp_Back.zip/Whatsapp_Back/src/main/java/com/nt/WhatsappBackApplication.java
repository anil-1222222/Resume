package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsappBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsappBackApplication.class, args);
	}

}
