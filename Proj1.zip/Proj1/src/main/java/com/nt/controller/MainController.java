package com.nt.controller;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nt.entity.Emp;
import com.nt.service.IEmpService;
import com.nt.validator.EmpValidator;

@Controller
public class MainController {
	
	@Autowired
	private IEmpService service;
	@Autowired
	private EmpValidator validator;
	
	@GetMapping("/")
	public String home(@PageableDefault(page=0,size=3,sort="empId",direction =Direction.ASC)Pageable oageable,Map<String, Object> map) {
         //List<Emp> list = service.getAllDetails();
		Page<Emp> page = service.getAllPageble(oageable);
		map.put("page", page);
		System.out.println(page);
		return "home";
	}
	
	@GetMapping("/add")
	public String addPage(@ModelAttribute("emp")Emp emp) {
		return "addPage";
	}
	
	@PostMapping("/add")
	public String addpage(@ModelAttribute("emp")Emp emp,RedirectAttributes atrs,BindingResult errors) {
		if(validator.supports(emp.getClass())) {
			validator.validate(emp, errors);
			if(errors.hasErrors()) {
				return "addPage";
			}
		}
		String register = service.registerEmp(emp);
		atrs.addFlashAttribute("msg", register);
		return "redirect:/";
		
	}
	
	@GetMapping("/edit")
	public String updatePage(@ModelAttribute("emp")Emp emp,@RequestParam("empId")int empId) {
		Emp emp2 = service.getEmpRecordById(empId).get();
		BeanUtils.copyProperties(emp2, emp);
		return "editPage";
	}
	
	@PostMapping("/edit")
	public String updatepage(@ModelAttribute("emp")Emp emp,RedirectAttributes atrs,BindingResult errors) {
		if(validator.supports(emp.getClass())) {
			validator.validate(emp, errors);
			if(errors.hasErrors()) {
				return "editPage";
			}
		}
		String register = service.updateEmp(emp);
		atrs.addFlashAttribute("msg", register);
		return "redirect:/";
	}
	
	@GetMapping("delete")
	public String deleteRecord(@RequestParam("empId")int empId,RedirectAttributes atrs) {
		String deleteRecord = service.deleteRecord(empId);
		//List<Emp> list = service.getAllDetails();
		atrs.addFlashAttribute("msg", deleteRecord);
		//map.put("list",list );
		return "redirect:/";
	}
	/*
	@PostMapping("states")
	public String showStatesByCountry(@RequestParam("country")String country,@ModelAttribute("emp")Emp emp,Map<String,Object>map,BindingResult errors,RedirectAttributes atrs) {
		if(validator.supports(emp.getClass())) {
			validator.validate(emp, errors);
			if(errors.hasErrors()) {
				return "Page";
			}
			List<String> statesList = service.getStatesByCountry(country);
			map.put("statesInfo", statesList);
			String register = service.registerEmp(emp);
			atrs.addFlashAttribute("msg", register);
		}
		return "redirect:/";
	}
	*/
	
	@PostMapping("states")
	public String showStatesByCountry(@RequestParam("country")String country,@ModelAttribute("emp")Emp emp,Map<String,Object>map) {
			List<String> statesList = service.getStatesByCountry(country);
			map.put("statesInfo", statesList);
			//String register = service.registerEmp(emp);
			//atrs.addFlashAttribute("msg", register);
		return "addPage";
	}
	
	@ModelAttribute("countriesInfo")
	public Set<String> populateCountries(){
		return service.getAllCountries();
	}
	
	@ModelAttribute("languagesInfo")
	public Set<String> populateLanguages(){
		return service.getAllLanguages();
	}
	
	@ModelAttribute("hobbiesInfo")
	public List<String> populateHobbies(){
		return service.getAllHobbies();
	}
	
	@InitBinder
	public void myInitBinder(WebDataBinder binder) {
		System.out.println("MainController.myInitBinder()");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		CustomDateEditor editor = new CustomDateEditor(sdf, false);
		binder.registerCustomEditor(java.util.Date.class, editor);
	}

}
