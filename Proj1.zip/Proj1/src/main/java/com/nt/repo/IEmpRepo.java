package com.nt.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.entity.Emp;

public interface IEmpRepo extends JpaRepository<Emp, Integer>{

}
